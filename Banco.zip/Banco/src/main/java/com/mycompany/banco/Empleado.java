 
package com.mycompany.banco;

 
public class Empleado extends Persona {
    private String puesto;
    private double salario;
    private int aniosTrabajando;

    public Empleado(String nombre, String numeroIdentificacion, String puesto, double salario, int aniosTrabajando) {
        super(nombre, numeroIdentificacion);
        this.puesto = puesto;
        this.salario = salario;
        this.aniosTrabajando = aniosTrabajando;
    }

    public int calcularDiasVacaciones() {
        int diasVacaciones = 5 + (aniosTrabajando - 1) * 2;
        return Math.min(diasVacaciones, 20); // Máximo 20 días de vacaciones
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Empleado: " + nombre + ", Puesto: " + puesto + ", Años: " + aniosTrabajando);
    }
}
    