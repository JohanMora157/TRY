 
package com.mycompany.banco;

 
public class EmpresaInversion {
    private String claveEmpresa;
    private String nombreEmpresa;
    private double porcentajeRetorno;
    
    public EmpresaInversion(String claveEmpresa, String nombreEmpresa, double porcentajeRetorno) {
        this.claveEmpresa = claveEmpresa;
        this.nombreEmpresa = nombreEmpresa;
        this.porcentajeRetorno = porcentajeRetorno;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }
    
    public double getPorcentajeRetorno() {
        return porcentajeRetorno;
    }
    
    public void mostrarInformacion() {
        System.out.println("Empresa: " + nombreEmpresa + ", clave: " + claveEmpresa);
    }
}
