 
package com.mycompany.banco;

 
public abstract class Cuenta {
    protected double saldo;
    
    public Cuenta(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public double getSaldo() {
        return saldo;
    }

    public abstract boolean retirar(double cantidad);
    
    public void depositar(double cantidad) {
        saldo += cantidad;
    }

    public abstract void calcularIntereses();
}
