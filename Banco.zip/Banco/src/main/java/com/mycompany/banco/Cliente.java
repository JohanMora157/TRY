 
package com.mycompany.banco;

 
public class Cliente extends Persona {
    private Cuenta cuenta;

    public Cliente(String nombre, String numeroIdentificacion, Cuenta cuenta) {
        super(nombre, numeroIdentificacion);
        this.cuenta = cuenta;
    }
    
    public Cuenta getCuenta() {
        return cuenta;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Cliente: " + nombre + ", ID: " + numeroIdentificacion);
    }
}
