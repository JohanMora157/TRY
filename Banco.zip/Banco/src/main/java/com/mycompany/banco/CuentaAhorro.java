 
package com.mycompany.banco;

 
public class CuentaAhorro extends Cuenta {
    private double tasaAhorroAnual;

    public CuentaAhorro(double saldoInicial, double tasaAhorroAnual) {
        super(Math.max(saldoInicial, 1000));  // Primer depósito de al menos $1000
        this.tasaAhorroAnual = tasaAhorroAnual;
    }

    @Override
    public boolean retirar(double cantidad) {
        if (saldo - cantidad >= 500) {  // No puede quedar con menos de $500
            saldo -= cantidad;
                                System.out.println("Retiro exitoso!");

            return true;
        }
        System.out.println("Error, no se puede quedar con menos de 500");
        return false;
    }

    @Override
    public void calcularIntereses() {
        saldo += (saldo * (tasaAhorroAnual / 12));  // Intereses mensuales
    }
}
