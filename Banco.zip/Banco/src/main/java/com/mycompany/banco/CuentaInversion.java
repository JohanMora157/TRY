 
package com.mycompany.banco;

 
public class CuentaInversion extends Cuenta {
    public CuentaInversion(double saldoInicial) {
        super(Math.max(saldoInicial, 25000));  // Monto inicial de al menos $25,000
    }

    @Override
    public boolean retirar(double cantidad) {
        if (saldo - cantidad >= 10000) {  // No puede quedar con menos de $10,000
            saldo -= cantidad;
                    System.out.println("Retiro exitoso!");

            return true;
        }
                System.out.println("Error, no se puede quedar con menos de 10000");

        return false;
    }

    @Override
    public void calcularIntereses() {
        // Las cuentas de inversión pueden tener otras reglas para calcular intereses
    }
}
