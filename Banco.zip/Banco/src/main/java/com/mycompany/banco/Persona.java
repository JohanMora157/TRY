 
package com.mycompany.banco;

 
public abstract class Persona {
    protected String nombre;
    protected String numeroIdentificacion;
    
    public Persona(String nombre, String numeroIdentificacion) {
        this.nombre = nombre;
        this.numeroIdentificacion = numeroIdentificacion;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }
    
    public abstract void mostrarInformacion();
}
