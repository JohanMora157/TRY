 
package com.mycompany.banco;

 
import java.util.ArrayList;
import java.util.List;

public class Banco {
      List<Cliente> clientes;
    private List<Empleado> empleados;
    private List<EmpresaInversion> empresasInversion;

    public Banco() {
        clientes = new ArrayList<>();
        empleados = new ArrayList<>();
        empresasInversion = new ArrayList<>();
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public void agregarEmpresaInversion(EmpresaInversion empresa) {
        empresasInversion.add(empresa);
    }

    public List<EmpresaInversion> obtenerOpcionesInversion() {
        return empresasInversion;
    }
    public static void main(String[] args) {
        // Crear el banco
        Banco bancoquete = new Banco();
        Cuenta cuentaAhorro = new CuentaAhorro(1000, 0.05);
        Cuenta cuentaAhorro2 = new CuentaAhorro(2000, 0.1);
        Cliente cliente1 = new Cliente("Juan Perez", "12345", cuentaAhorro);
        Cliente cliente2 = new Cliente("Johan Mora", "111", cuentaAhorro2);
        EmpresaInversion empresa1 = new EmpresaInversion("1234","carvajal", 200.0);
        bancoquete.agregarCliente(cliente1);
        bancoquete.agregarCliente(cliente2);
        bancoquete.agregarEmpresaInversion(empresa1);

        // Crear empleados
        Empleado empleado1 = new Empleado("Ana Gomez", "67890", "Cajero", 1500.0, 3);
        bancoquete.agregarEmpleado(empleado1);
        
        // Mostrar información
        cliente1.mostrarInformacion();
        empleado1.mostrarInformacion();
        empresa1.mostrarInformacion();
        
       
    }
}
