package ui;

import java.time.LocalDate;
import java.util.Scanner;
import model.Tournament;

public class SystemTournament {

    private final Scanner scanner;
    private final Tournament control;

    public SystemTournament() {
        scanner = new Scanner(System.in);
        control = new Tournament();

    }

    public static void main(String[] args) {
        SystemTournament exe = new SystemTournament();
        exe.registerTournament();
        exe.menuRegister();
        exe.control.preUpdate();
    }

    /**
     * Descripción: Menú principal del programa para registrar y gestionar un torneo
     * de fútbol.
     * Permite registrar equipos, jugadores, árbitros, generar grupos, mostrar
     * partidos,
     * jugar partidos y visualizar posiciones de equipos.
     *
     * pre:
     * - Los datos ingresados deben ser válidos según la opción seleccionada.
     *
     * post:
     * - Dependiendo de la opción seleccionada, el sistema ejecuta la accion
     * correspondiente
     * 
     */
    public void menuRegister() {
        System.out.println("\n--------Bienvenido al programa--------");
        int opcion;
        // Consume newline left-over
        while (true) {
            System.out.println(
                    "OPCIONES\n1. Registrar un equipo\n2. Registrar un jugador\n3. Registrar un arbitro\n4. Generar grupos A y B\n5. Mostrar los partidos de los grupos\n6. Mostrar la informacion de los partidos\n7. Jugar partidos\n8. Imprimir jugadores\n9. Imprimir marcadores\n10. Mostrar maximo goleador\n11. Mostrar mejor equipo con fair play\n12. Eficiencias o indice del arbitro\n0  . Salir");
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion) {

                case 1 -> registerTeam();
                case 2 -> registerPlayer();
                case 3 -> registerReferee();
                case 4 -> generateGroupAB();
                case 5 -> printGroups();
                case 6 -> showMatches();
                case 7 -> playMatches();
                case 8 -> printPlayers();
                case 9 -> printPositions();
                case 10 -> maxScorer();
                case 11 -> bestFairPlay();
                case 12 -> eficinecy();

                case 0 -> System.exit(0);
                default -> System.out.println("Opcion no valida");
            }

        }
    }

    /**
     * Descripción: Registra un nuevo torneo, solicitando al usuario el nombre y la
     * fecha de inicio.
     * 
     * pre:
     * - El usuario debe ingresar un nombre válido para el torneo.
     * - La fecha de inicio del torneo debe ingresarse en el formato "yyyy-MM-dd" y
     * debe ser una fecha válida.
     * 
     * post:
     * - El nombre y la fecha de inicio del torneo se almacenan en el controlador.
     * - Si el formato de la fecha ingresada es incorrecto, el programa lanzará una
     * excepción de formato de fecha.
     */

    public void registerTournament() {
        System.out.print("<REGISTRAR TORNEO>\n>Digite el nombre del torneo> \n");
        String nameTournament = "epa";

        System.out.print(">Digite la fecha de inicio del torneo (yyyy-MM-dd) \n ");
        String startDate = "2000-08-09";// scanner.nextLine();
        LocalDate startDateParsed = LocalDate.parse(startDate);

        control.setName(nameTournament);
        control.setDate(startDateParsed);
    }

    /**
     * Descripción: Registra un equipo solicitando el nombre, país y entrenador.
     *
     * pre:
     * - El nombre del equipo, país y entrenador deben ser ingresados correctamente
     * por el usuario.
     *
     * post:
     * - Se añade un nuevo equipo a la lista de equipos en el sistema.
     * - Si el equipo no se pudo agregar, se muestra un mensaje de error.
     */
    public void registerTeam() {
        System.out.print("REGISTRAR EQUIPO\nDigite el nombre del equipo \n> ");
        String nameTeam = scanner.nextLine();

        System.out.print("Digite el pais del equipo \n> ");
        String countryTeam = scanner.nextLine();

        System.out.print("Digite el nombre del coach del equipo \n> ");
        String coachTeam = scanner.nextLine();

        if (control.addTeam(nameTeam, countryTeam, coachTeam)) {
            System.out.println("Equipo registrado correctamente");
        } else {
            System.out.println("Error al registrar el equipo	");
        }
    }

    /**
     * Descripción: Registra un jugador asociado a un equipo, pidiendo nombre, país,
     * dorsal y posición.
     *
     * pre:
     * - El equipo debe existir en el sistema.
     * - El dorsal y la posición deben ser válidos.
     *
     * post:
     * - El jugador se añade al equipo especificado.
     * - Si no se pudo agregar el jugador, se muestra un mensaje de error.
     */
    public void registerPlayer() {

        System.out.println("REGISTRAR JUGADOR\n" + control.showTeams());

        System.out.print("Digite el nombre del equipo al que pertenece el jugador \n> ");
        String nameTeam = scanner.nextLine();

        System.out.print("Digite el pais del jugador \n> ");
        String countryPlayer = scanner.nextLine();

        System.out.print("Digite el nombre del jugador \n> ");
        String namePlayer = scanner.nextLine();

        System.out.print("Digite el dorsal del jugador \n> ");
        String dorsalPlayer = scanner.nextLine();

        System.out.println(
                "Digite la posicion del jugador \n1. Portero\n2. Defensa\n3. Centrocampista\n4. Delantero\n> ");
        int positionPlayer = scanner.nextInt();

        if (control.addPlayerToTeam(nameTeam, countryPlayer, namePlayer, dorsalPlayer, positionPlayer)) {
            System.out.println("Jugador registrado correctamente");
        } else {
            System.out.println("Error al registrar el jugador");
        }
    }

    /**
     * Descripción: Registra un árbitro, incluyendo nombre, país, ID y tipo
     * (principal o auxiliar).
     *
     * pre:
     * - Los datos deben ingresarse correctamente por el usuario.
     * - El tipo debe ser 1 (principal) o 2 (auxiliar).
     *
     * post:
     * - El árbitro se agrega al sistema.
     * - Si el árbitro no pudo ser agregado, se muestra un mensaje de error.
     */
    public void registerReferee() {

        System.out.print("REGISTRAR REFEREE\nDigite el nombre del referee \n> ");
        String nameReferee = scanner.nextLine();

        System.out.print("Digite el pais del referee \n> ");
        String countryReferee = scanner.nextLine();

        System.out.println("Dgite el id del referee \n> ");
        String idReferee = scanner.nextLine();

        System.out.println("Digite el tipo de referee \n1. Principal\n2. Auxiliar\n> ");

        int typeReferee = scanner.nextInt();

        if (control.addReferee(nameReferee, countryReferee, idReferee, typeReferee)) {
            System.out.println("Referee registrado correctamente");
        } else {
            System.out.println("Error al registrar el referee");
        }

    }

    /**
     * Descripción: Genera y muestra los grupos A y B con los equipos registrados.
     *
     * pre:
     * - Los equipos deben estar previamente registrados.
     *
     * post:
     * - Se generan y muestran los grupos.
     */
    public void generateGroupAB() {

        System.out.println(control.createGroupsAB());
        control.addMatches();
    }

    /**
     * Descripción: Imprime la lista de partidos generados con sus fechas.
     *
     * pre:
     * - Los grupos deben estar generados.
     *
     * post:
     * - Se muestran los partidos con sus fechas.
     */
    public void printGroups() {

        System.out.println(control.generateMatchDates(control.getDate()));

    }

    /**
     * Descripción: Muestra los partidos registrados en el sistema.
     *
     * pre:
     * - Los partidos deben estar previamente generados.
     *
     * post:
     * - Se muestra la lista de partidos.
     * - Si no hay partidos, se notifica al usuario.
     */
    public void showMatches() {
        if (control.printMatches().isEmpty()) {
            System.out.println("No hay partidos registrados.(Usar opcion 4 primero)");
        }
        System.out.println(control.printMatches());

    }

    /**
     * Descripción: Permite al usuario registrar el marcador de un partido y anotar
     * los goles.
     *
     * pre:
     * - Los partidos y jugadores deben estar previamente registrados.
     *
     * post:
     * - Los goles y el resultado se registran correctamente para el partido
     * especificado.
     */
    public void playMatches() {
        int goalsTeam1 = 0, goalsTeam2 = 0, cardsToReferee = 0;
        String dorsal, cardToPlayer, assistDorsal;
        if (control.printMatches().isEmpty()) {
            System.out.println("No hay partidos registrados.(Usar opcion 4 primero)");
            return;
        }

        System.out.println(control.printMatches());
        System.out.println("Digite el numero del partido al cual desea registrar el marcador [1-12]");
        int numMatch = scanner.nextInt();
        if (!control.analizeMatches(numMatch).isEmpty()) {
            System.out.println(control.analizeMatches(numMatch));
            return;

        }

        for (int team = 1; team <= 2; team++) {
            while (true) {
                scanner.nextLine();
                System.out.println(control.printPlayerTeam(numMatch, team));

                while (true) {

                    System.out.println("Quien marco en el equipo " + team + "?, Digite el numero de su dorsal");
                    dorsal = scanner.nextLine();

                    if (!control.analizePlayer(dorsal, numMatch, team)) {
                        System.out.println("El jugador no pertenece al equipo");

                    } else {
                        break;

                    }

                }
                System.out.println("Cuantos goles?");
                int goals = scanner.nextInt();
                scanner.nextLine();

                if (team == 1) {
                    goalsTeam1 += goals;

                } else {
                    goalsTeam2 += goals;
                }

                for (int i = 0; i < goals; i++) {

                    while (true) {
                        System.out.println("Quien lo asistio en el gol " + (i + 1) + "? nadie= DEJAR VACIO");
                        assistDorsal = scanner.nextLine();
                        if (assistDorsal.isEmpty()) {
                            break;
                        }
                        if (!control.analizePlayer(assistDorsal, numMatch, team)) {
                            System.out.println("El jugador no pertenece al equipo");

                        } else {
                            break;
                        }

                    }

                    if (!assistDorsal.isEmpty()) {
                        control.setAssistToPlayer(assistDorsal);
                    }
                }

                if (control.setGoalToPlayer(dorsal, goals)) {
                    System.out.println("Goles y asistencias registradas correctamente");
                } else {
                    System.out.println("Error al registrar el gol");
                }
                System.out.println("Desea registrar otro gol? [1. Si, 2. No]");
                int option = scanner.nextInt();
                if (option == 2) {
                    break;
                }
            }
        }

        for (int team = 1; team <= 2; team++) {
            while (true) {
                scanner.nextLine();
                System.out.println(control.printPlayerTeam(numMatch, team));

                while (true) {
                    System.out.println("Que jugador fue amonestado? \n Digite el numero de su dorsal");
                    cardToPlayer = scanner.nextLine();

                    if (!control.analizePlayer(cardToPlayer, numMatch, team)) {
                        System.out.println("El jugador no pertenece al equipo");

                    } else {
                        break;
                    }

                }
                System.out.println("Digite el tipo de tarjeta [1. Amarilla, 2. Roja]");
                int typeCard = scanner.nextInt();

                if (typeCard == 1) {
                    System.out.println("Cuantas tarjetas amarillas tiene el jugador?");
                    int yellowCards = scanner.nextInt();
                    cardsToReferee += yellowCards;
                    if (control.setYellowCardToPlayer(cardToPlayer, yellowCards)) {
                        System.out.println("Tarjeta amarilla registrada correctamente");
                    } else {
                        System.out.println("Error al registrar la tarjeta");
                    }
                } else {
                    if (control.setRedCardToPlayer(cardToPlayer, 1)) {
                        cardsToReferee++;
                        System.out.println("Tarjeta roja registrada correctamente");
                    } else {
                        System.out.println("Error al registrar la tarjeta");
                    }
                }

                System.out.println("Desea registrar otra tarjeta? [1. Si, 2. No]");
                int option = scanner.nextInt();
                if (option == 2) {
                    break;
                }
            }

        }
        control.playMatches(numMatch, goalsTeam1, goalsTeam2, cardsToReferee);
    }

    /**
     * Descripción: Muestra la lista de jugadores de un equipo especificado por el
     * usuario.
     *
     * pre:
     * - Debe existir al menos un equipo y sus jugadores en el sistema.
     *
     * post:
     * - Se muestra la lista de jugadores del equipo seleccionado.
     */
    public void printPlayers() {
        System.out.println(control.printTeams());
        System.out.println("Digite el nombre del equipo");
        String nameTeam = scanner.nextLine();

        System.out.println(control.printPlayerTeam(nameTeam.toUpperCase()));
    }

    /**
     * Descripción: Muestra las posiciones de los equipos en el torneo.
     *
     * pre:
     * - Los partidos deben haberse jugado para calcular las posiciones.
     *
     * post:
     * - Se muestra la clasificación actual de los equipos.
     */
    public void printPositions() {
        System.out.println(control.listPositions());

    }

    public void maxScorer() {
        System.out.println(control.topGoalsScorer());
    }

    public void bestFairPlay() {
        System.out.println(control.teamFairPlay());
    }

    public void eficinecyTeam() {
        scanner.nextLine();
        System.out.println(control.printTeams());

        System.out.println("Digite el nombre del equipo para ver su eficiencia");
        String nameTeam = scanner.nextLine();

        System.out.println(control.efficiencyTeam(nameTeam.toUpperCase()));

    }

    public void eficinecyPlayer() {
        scanner.nextLine();
        System.out.println(control.printTeams());
        System.out.println("Cual es el equipo del jugador?");
        String nameTeam = scanner.nextLine();

        System.out.println(control.printPlayerTeam(nameTeam.toUpperCase()));

        System.out.println("Digite el dorsal del jugador para ver su eficiencia");
        String dorsalPlayer = scanner.nextLine();

        System.out.println(control.efficiencyPlayer(dorsalPlayer, nameTeam.toUpperCase()));

    }

    public void eficinecyRferee() {
        scanner.nextLine();
        System.out.println("Digite el nombre del arbitro para ver su indice de cartas por partido");
        String nameReferee = scanner.nextLine();

        System.out.println(control.efficiencyReferee(nameReferee));

    }

    public void eficinecy() {

        System.out.println(
                "1. Eficiencia de un equipo\n2. Eficiencia de un jugador\n3. Indice de targetas de un arbitro");
        int option = scanner.nextInt();
        switch (option) {
            case 1 -> eficinecyTeam();
            case 2 -> eficinecyPlayer();
            case 3 -> eficinecyRferee();

            default -> System.out.println("Opcion no valida");
        }
    }

}
