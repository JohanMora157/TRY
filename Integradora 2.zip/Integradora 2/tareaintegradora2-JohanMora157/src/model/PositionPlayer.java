package model;

public enum PositionPlayer {

    GOALKEEPER, DEFENDER, MIDFIELDER, FORWARD;

}