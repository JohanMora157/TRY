package model;

public enum TypeReferee {

    MAIN, AUXILIARY;

}
