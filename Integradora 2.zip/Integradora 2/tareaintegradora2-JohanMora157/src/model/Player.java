package model;

public class Player {

    private String country;
    private String name;
    private String dorsal;
    private PositionPlayer position;
    private int goals = 0;
    private int assists = 0;
    private int yellowCards = 0;
    private int redCards = 0;
    private int MatchPlayed = 0;

    public Player(String country, String name, String dorsal, PositionPlayer position) {
        this.country = country;
        this.name = name;
        this.dorsal = dorsal;
        this.position = position;
        this.MatchPlayed = 0;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDorsal() {
        return dorsal;
    }

    public void setDorsal(String dorsal) {
        this.dorsal = dorsal;
    }

    public PositionPlayer getPosition() {
        return position;
    }

    public void setPosition(PositionPlayer position) {
        this.position = position;
    }

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    public int getAssists() {
        return assists;
    }

    public void setAssists(int assists) {
        this.assists = assists;
    }

    public int getYellowCards() {
        return yellowCards;
    }

    public void setYellowCards(int yellowCards) {
        this.yellowCards = yellowCards;
    }

    public int getRedCards() {
        return redCards;
    }

    public void setRedCards(int redCards) {
        this.redCards = redCards;
    }

    @Override
    public String toString() {
        return "Player [country=" + country + ", name=" + name + ", dorsal=" + dorsal + "]";
    }

    public int getMatchPlayed() {
        return MatchPlayed;
    }

    public void setMatchPlayed(int MatchPlayed) {
        this.MatchPlayed = MatchPlayed;
    }
}
