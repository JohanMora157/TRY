package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Tournament {

    private String name;
    private LocalDate date;
    private final Random random;
    private int verifyGroup = 0;
    private final List<Team> groupA;
    private final List<Team> groupB;

    private final List<Team> teams;
    private final List<Referee> mainReferee;
    private final List<Referee> AuxReferees;
    private final List<Match> matches;

    public Tournament() {
        teams = new ArrayList<>(8);
        mainReferee = new ArrayList<>(4);
        AuxReferees = new ArrayList<>(8);
        random = new Random();
        groupA = new ArrayList<>(4);
        groupB = new ArrayList<>(4);
        matches = new ArrayList<>(12);
        preUpdate();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    /**
     * Descripcion: Agrega un equipo al sistema, con un límite de 8 equipos.
     *
     * @param nameTeam  Nombre del equipo.
     * @param country   País del equipo.
     * @param nameCoach Nombre del entrenador.
     * @return `true` si el equipo se agregó correctamente, `false` si ya hay 8
     *         equipos.
     */
    public boolean addTeam(String nameTeam, String country, String nameCoach) {
        if (teams.size() < 8) { // Limit of 8 teams
            teams.add(new Team(nameTeam, country, nameCoach));
            return true;
        }
        return false;
    }

    /**
     * Descripcion: Agrega un árbitro al sistema, con un límite de 4 árbitros
     * principales y 8 auxiliares.
     *
     * @param id             Identificación del árbitro.
     * @param nameReferee    Nombre del árbitro.
     * @param countryReferee País del árbitro.
     * @param type           Tipo de árbitro (1 = principal, 2 = auxiliar).
     * @return `true` si el árbitro fue agregado, `false` si el límite se ha
     *         alcanzado.
     */
    public boolean addReferee(String id, String nameReferee, String countryReferee, int type) {
        TypeReferee t = TypeReferee.AUXILIARY;
        switch (type) {
            case 1 -> t = TypeReferee.MAIN;
            case 2 -> t = TypeReferee.AUXILIARY;
        }

        if (type == 1) {
            if (mainReferee.size() < 4) { // Limit of 12 referees
                mainReferee.add(new Referee(id, nameReferee, countryReferee, t));
                return true;
            }

        } else {
            if (AuxReferees.size() < 8) { // Limit of 12 referees
                AuxReferees.add(new Referee(id, nameReferee, countryReferee, t));
                return true;
            }
        }

        return false;
    }

    /**
     * Descripcion: Muestra todos los equipos registrados.
     *
     * @return Una cadena que contiene la lista de todos los equipos.
     */
    public String showTeams() {
        StringBuilder list = new StringBuilder();
        for (Team team : teams) {
            if (team != null) {
                list.append(team.toString()).append("\n");
            }
        }
        return list.toString();
    }

    /**
     * Descripcion: Busca un equipo por su nombre.
     *
     * @param nameTeam Nombre del equipo a buscar.
     * @return El equipo si se encuentra, o `null` si no existe.
     */

    public Team searchTeam(String nameTeam) {
        for (Team team : teams) {
            if (team != null && team.getNameTeam().equals(nameTeam)) {
                return team;
            }
        }
        return null;
    }

    /**
     * Descripcion: Agrega un jugador a un equipo específico.
     *
     * @param nameTeam Nombre del equipo.
     * @param country  País del jugador.
     * @param name     Nombre del jugador.
     * @param dorsal   Número de dorsal del jugador.
     * @param position Posición del jugador (1 = delantero, 2 = defensa, 3 =
     *                 centrocampista, 4 = portero).
     * @return `true` si el jugador fue agregado correctamente, `false` si el equipo
     *         no existe o el jugador no se pudo agregar.
     */
    public boolean addPlayerToTeam(String nameTeam, String country, String name, String dorsal, int position) {
        PositionPlayer p = switch (position) {
            case 1 -> PositionPlayer.FORWARD;
            case 2 -> PositionPlayer.DEFENDER;
            case 3 -> PositionPlayer.MIDFIELDER;
            case 4 -> PositionPlayer.GOALKEEPER;
            default -> PositionPlayer.FORWARD;
        };

        Team searchTeam = searchTeam(nameTeam);
        if (searchTeam == null) {
            return false;
        }

        Player newPlayer = new Player(country, name, dorsal, p);
        return searchTeam.addPlayer(newPlayer);

    }

    /**
     * Descripcion: Pre-carga datos de equipos, árbitros y jugadores en el torneo.
     *
     * @pre No hay equipos, árbitros ni jugadores cargados en el torneo.
     * @post Se añaden 8 equipos, 4 árbitros principales, 8 árbitros auxiliares y
     *       varios jugadores a los equipos.
     */
    public void preUpdate() {
        teams.add(new Team("CALI", "Colombia", "Pepito"));
        teams.add(new Team("MEDELLIN", "Brasil", "Juanito"));
        teams.add(new Team("BOGOTA", "Ecuador", "Pablito"));
        teams.add(new Team("BUCARAMANGA", "Inglaterra", "Carlos"));
        teams.add(new Team("LIVERPOOL", "Chile", "klopp"));
        teams.add(new Team("CITY", "Gales", "pep"));
        teams.add(new Team("UNITED", "España", "hag"));
        teams.add(new Team("WOLVES", "Mexico", "traore"));

        mainReferee.add(new Referee("1", "Juan", "Colombia", TypeReferee.MAIN));
        mainReferee.add(new Referee("2", "Pedro", "Brasil", TypeReferee.MAIN));
        mainReferee.add(new Referee("3", "Maria", "Panama", TypeReferee.MAIN));
        mainReferee.add(new Referee("4", "Laura", "australia", TypeReferee.MAIN));
        AuxReferees.add(new Referee("5", "Jose", "EEUU", TypeReferee.AUXILIARY));
        AuxReferees.add(new Referee("6", "Ana", "Gales", TypeReferee.AUXILIARY));
        AuxReferees.add(new Referee("7", "Carlos", "Venezuela", TypeReferee.AUXILIARY));
        AuxReferees.add(new Referee("8", "Sofia", "Inglaterra", TypeReferee.AUXILIARY));
        AuxReferees.add(new Referee("9", "Luis", "Bolivia", TypeReferee.AUXILIARY));
        AuxReferees.add(new Referee("10", "Lucia", "Uruguay", TypeReferee.AUXILIARY));
        AuxReferees.add(new Referee("11", "Diego", "España", TypeReferee.AUXILIARY));
        AuxReferees.add(new Referee("12", "Valentina", "Peru", TypeReferee.AUXILIARY));

        Player P1 = new Player("SENEGAL", "Carlos", "1", PositionPlayer.DEFENDER);
        teams.get(0).addPlayer(P1);
        Player P2 = new Player("ARGENTINA", "Lionel", "2", PositionPlayer.FORWARD);
        teams.get(1).addPlayer(P2);
        Player P3 = new Player("BRASIL", "Neymar", "3", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P3);
        Player P4 = new Player("FRANCIA", "Kylian", "4", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P4);
        Player P5 = new Player("PORTUGAL", "Cristiano", "5", PositionPlayer.FORWARD);
        teams.get(4).addPlayer(P5);
        Player P6 = new Player("INGLATERRA", "Harry", "6", PositionPlayer.FORWARD);
        teams.get(5).addPlayer(P6);
        Player P7 = new Player("BELGICA", "Kevin", "7", PositionPlayer.MIDFIELDER);
        teams.get(6).addPlayer(P7);
        Player P8 = new Player("CROACIA", "Luka", "8", PositionPlayer.MIDFIELDER);
        teams.get(7).addPlayer(P8);
        Player P9 = new Player("ESPAÑA", "Pedri", "9", PositionPlayer.MIDFIELDER);
        teams.get(0).addPlayer(P9);
        Player P10 = new Player("ITALIA", "Marco", "10", PositionPlayer.FORWARD);
        teams.get(1).addPlayer(P10);
        Player P11 = new Player("ALEMANIA", "Joshua", "11", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P11);
        Player P12 = new Player("URUGUAY", "Luis", "12", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P12);
        Player P13 = new Player("HOLANDA", "Virgil", "13", PositionPlayer.DEFENDER);
        teams.get(4).addPlayer(P13);
        Player P14 = new Player("DINAMARCA", "Christian", "14", PositionPlayer.MIDFIELDER);
        teams.get(5).addPlayer(P14);
        Player P15 = new Player("MEXICO", "Hirving", "15", PositionPlayer.FORWARD);
        teams.get(6).addPlayer(P15);
        Player P16 = new Player("ESTADOS UNIDOS", "Christian", "16", PositionPlayer.MIDFIELDER);
        teams.get(7).addPlayer(P16);
        Player P17 = new Player("SUIZA", "Xherdan", "17", PositionPlayer.MIDFIELDER);
        teams.get(0).addPlayer(P17);
        Player P18 = new Player("COLOMBIA", "James", "18", PositionPlayer.MIDFIELDER);
        teams.get(1).addPlayer(P18);
        Player P19 = new Player("CHILE", "Alexis", "19", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P19);
        Player P20 = new Player("PERU", "Paolo", "20", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P20);
        Player P21 = new Player("SENEGAL", "Sadio", "21", PositionPlayer.FORWARD);
        teams.get(4).addPlayer(P21);
        Player P22 = new Player("ARGENTINA", "Paulo", "22", PositionPlayer.FORWARD);
        teams.get(5).addPlayer(P22);
        Player P23 = new Player("BRASIL", "Alisson", "23", PositionPlayer.GOALKEEPER);
        teams.get(6).addPlayer(P23);
        Player P24 = new Player("FRANCIA", "Hugo", "24", PositionPlayer.GOALKEEPER);
        teams.get(7).addPlayer(P24);
        Player P25 = new Player("PORTUGAL", "Ruben", "25", PositionPlayer.GOALKEEPER);
        teams.get(0).addPlayer(P25);
        Player P26 = new Player("INGLATERRA", "Jordan", "26", PositionPlayer.GOALKEEPER);
        teams.get(1).addPlayer(P26);
        Player P27 = new Player("BELGICA", "Thibaut", "27", PositionPlayer.GOALKEEPER);
        teams.get(2).addPlayer(P27);
        Player P28 = new Player("CROACIA", "Dominik", "28", PositionPlayer.GOALKEEPER);
        teams.get(3).addPlayer(P28);
        Player P29 = new Player("ESPAÑA", "Unai", "29", PositionPlayer.GOALKEEPER);
        teams.get(4).addPlayer(P29);
        Player P30 = new Player("ITALIA", "Gianluigi", "30", PositionPlayer.GOALKEEPER);
        teams.get(5).addPlayer(P30);
        Player P31 = new Player("ALEMANIA", "Manuel", "31", PositionPlayer.GOALKEEPER);
        teams.get(6).addPlayer(P31);
        Player P32 = new Player("URUGUAY", "Fernando", "32", PositionPlayer.GOALKEEPER);
        teams.get(7).addPlayer(P32);
        Player P33 = new Player("HOLANDA", "Jasper", "33", PositionPlayer.GOALKEEPER);
        teams.get(0).addPlayer(P33);
        Player P34 = new Player("DINAMARCA", "Kasper", "34", PositionPlayer.GOALKEEPER);
        teams.get(1).addPlayer(P34);
        Player P35 = new Player("MEXICO", "Guillermo", "35", PositionPlayer.GOALKEEPER);
        teams.get(2).addPlayer(P35);
        Player P36 = new Player("ESTADOS UNIDOS", "Zack", "36", PositionPlayer.GOALKEEPER);
        teams.get(3).addPlayer(P36);
        Player P37 = new Player("SUIZA", "Yann", "37", PositionPlayer.GOALKEEPER);
        teams.get(4).addPlayer(P37);
        Player P38 = new Player("COLOMBIA", "David", "38", PositionPlayer.GOALKEEPER);
        teams.get(5).addPlayer(P38);
        Player P39 = new Player("CHILE", "Claudio", "39", PositionPlayer.GOALKEEPER);
        teams.get(6).addPlayer(P39);
        Player P40 = new Player("PERU", "Pedro", "40", PositionPlayer.GOALKEEPER);
        teams.get(7).addPlayer(P40);
        Player P41 = new Player("SENEGAL", "Kalidou", "41", PositionPlayer.DEFENDER);
        teams.get(0).addPlayer(P41);
        Player P42 = new Player("ARGENTINA", "Nicolas", "42", PositionPlayer.DEFENDER);
        teams.get(1).addPlayer(P42);
        Player P43 = new Player("BRASIL", "Marquinhos", "43", PositionPlayer.DEFENDER);
        teams.get(2).addPlayer(P43);
        Player P44 = new Player("FRANCIA", "Raphael", "44", PositionPlayer.DEFENDER);
        teams.get(3).addPlayer(P44);
        Player P45 = new Player("PORTUGAL", "Pepe", "45", PositionPlayer.DEFENDER);
        teams.get(4).addPlayer(P45);
        Player P46 = new Player("INGLATERRA", "John", "46", PositionPlayer.DEFENDER);
        teams.get(5).addPlayer(P46);
        Player P47 = new Player("BELGICA", "Toby", "47", PositionPlayer.DEFENDER);
        teams.get(6).addPlayer(P47);
        Player P48 = new Player("CROACIA", "Josko", "48", PositionPlayer.DEFENDER);
        teams.get(7).addPlayer(P48);
        Player P49 = new Player("ESPAÑA", "Sergio", "49", PositionPlayer.DEFENDER);
        teams.get(0).addPlayer(P49);
        Player P50 = new Player("ITALIA", "Leonardo", "50", PositionPlayer.DEFENDER);
        teams.get(1).addPlayer(P50);
        Player P51 = new Player("ALEMANIA", "Antonio", "51", PositionPlayer.DEFENDER);
        teams.get(2).addPlayer(P51);
        Player P52 = new Player("URUGUAY", "Diego", "52", PositionPlayer.DEFENDER);
        teams.get(3).addPlayer(P52);
        Player P53 = new Player("HOLANDA", "Matthijs", "53", PositionPlayer.DEFENDER);
        teams.get(4).addPlayer(P53);
        Player P54 = new Player("DINAMARCA", "Simon", "54", PositionPlayer.DEFENDER);
        teams.get(5).addPlayer(P54);
        Player P55 = new Player("MEXICO", "Cesar", "55", PositionPlayer.DEFENDER);
        teams.get(6).addPlayer(P55);
        Player P56 = new Player("ESTADOS UNIDOS", "Sergino", "56", PositionPlayer.DEFENDER);
        teams.get(7).addPlayer(P56);
        Player P57 = new Player("SUIZA", "Manuel", "57", PositionPlayer.DEFENDER);
        teams.get(0).addPlayer(P57);
        Player P58 = new Player("COLOMBIA", "Yerry", "58", PositionPlayer.DEFENDER);
        teams.get(1).addPlayer(P58);
        Player P59 = new Player("CHILE", "Gary", "59", PositionPlayer.DEFENDER);
        teams.get(2).addPlayer(P59);
        Player P60 = new Player("PERU", "Luis", "60", PositionPlayer.DEFENDER);
        teams.get(3).addPlayer(P60);

        Player P61 = new Player("SENEGAL", "Pape", "61", PositionPlayer.DEFENDER);
        teams.get(4).addPlayer(P61);
        Player P62 = new Player("ARGENTINA", "Gonzalo", "62", PositionPlayer.DEFENDER);
        teams.get(5).addPlayer(P62);
        Player P63 = new Player("BRASIL", "Dani", "63", PositionPlayer.DEFENDER);
        teams.get(6).addPlayer(P63);
        Player P64 = new Player("FRANCIA", "Theo", "64", PositionPlayer.DEFENDER);
        teams.get(7).addPlayer(P64);
        Player P65 = new Player("PORTUGAL", "Joao", "65", PositionPlayer.DEFENDER);
        teams.get(0).addPlayer(P65);
        Player P66 = new Player("INGLATERRA", "Kyle", "66", PositionPlayer.DEFENDER);
        teams.get(1).addPlayer(P66);
        Player P67 = new Player("BELGICA", "Jan", "67", PositionPlayer.DEFENDER);
        teams.get(2).addPlayer(P67);
        Player P68 = new Player("CROACIA", "Dejan", "68", PositionPlayer.DEFENDER);
        teams.get(3).addPlayer(P68);
        Player P69 = new Player("ESPAÑA", "Jordi", "69", PositionPlayer.DEFENDER);
        teams.get(4).addPlayer(P69);
        Player P70 = new Player("ITALIA", "Alessandro", "70", PositionPlayer.DEFENDER);
        teams.get(5).addPlayer(P70);
        Player P71 = new Player("ALEMANIA", "Matthias", "71", PositionPlayer.DEFENDER);
        teams.get(6).addPlayer(P71);
        Player P72 = new Player("URUGUAY", "Jose", "72", PositionPlayer.DEFENDER);
        teams.get(7).addPlayer(P72);
        Player P73 = new Player("HOLANDA", "Daley", "73", PositionPlayer.DEFENDER);
        teams.get(0).addPlayer(P73);
        Player P74 = new Player("DINAMARCA", "Joachim", "74", PositionPlayer.DEFENDER);
        teams.get(1).addPlayer(P74);
        Player P75 = new Player("MEXICO", "Johan", "75", PositionPlayer.DEFENDER);
        teams.get(2).addPlayer(P75);
        Player P76 = new Player("ESTADOS UNIDOS", "John", "76", PositionPlayer.DEFENDER);
        teams.get(3).addPlayer(P76);
        Player P77 = new Player("SUIZA", "Ricardo", "77", PositionPlayer.DEFENDER);
        teams.get(4).addPlayer(P77);
        Player P78 = new Player("COLOMBIA", "Frank", "78", PositionPlayer.DEFENDER);
        teams.get(5).addPlayer(P78);
        Player P79 = new Player("CHILE", "Mauricio", "79", PositionPlayer.DEFENDER);
        teams.get(6).addPlayer(P79);
        Player P80 = new Player("PERU", "Anderson", "80", PositionPlayer.DEFENDER);
        teams.get(7).addPlayer(P80);
        Player P81 = new Player("SENEGAL", "Idrissa", "81", PositionPlayer.MIDFIELDER);
        teams.get(0).addPlayer(P81);
        Player P82 = new Player("ARGENTINA", "Leandro", "82", PositionPlayer.MIDFIELDER);
        teams.get(1).addPlayer(P82);
        Player P83 = new Player("BRASIL", "Casemiro", "83", PositionPlayer.MIDFIELDER);
        teams.get(2).addPlayer(P83);
        Player P84 = new Player("FRANCIA", "N'Golo", "84", PositionPlayer.MIDFIELDER);
        teams.get(3).addPlayer(P84);
        Player P85 = new Player("PORTUGAL", "Bruno", "85", PositionPlayer.MIDFIELDER);
        teams.get(4).addPlayer(P85);
        Player P86 = new Player("INGLATERRA", "Declan", "86", PositionPlayer.MIDFIELDER);
        teams.get(5).addPlayer(P86);
        Player P87 = new Player("BELGICA", "Youri", "87", PositionPlayer.MIDFIELDER);
        teams.get(6).addPlayer(P87);
        Player P88 = new Player("CROACIA", "Marcelo", "88", PositionPlayer.MIDFIELDER);
        teams.get(7).addPlayer(P88);
        Player P89 = new Player("ESPAÑA", "Koke", "89", PositionPlayer.MIDFIELDER);
        teams.get(0).addPlayer(P89);
        Player P90 = new Player("ITALIA", "Jorginho", "90", PositionPlayer.MIDFIELDER);
        teams.get(1).addPlayer(P90);
        Player P91 = new Player("ALEMANIA", "Ilkay", "91", PositionPlayer.MIDFIELDER);
        teams.get(2).addPlayer(P91);
        Player P92 = new Player("URUGUAY", "Rodrigo", "92", PositionPlayer.MIDFIELDER);
        teams.get(3).addPlayer(P92);
        Player P93 = new Player("HOLANDA", "Frenkie", "93", PositionPlayer.MIDFIELDER);
        teams.get(4).addPlayer(P93);
        Player P94 = new Player("DINAMARCA", "Thomas", "94", PositionPlayer.MIDFIELDER);
        teams.get(5).addPlayer(P94);
        Player P95 = new Player("MEXICO", "Edson", "95", PositionPlayer.MIDFIELDER);
        teams.get(6).addPlayer(P95);
        Player P96 = new Player("ESTADOS UNIDOS", "Weston", "96", PositionPlayer.MIDFIELDER);
        teams.get(7).addPlayer(P96);
        Player P97 = new Player("SUIZA", "Remo", "97", PositionPlayer.MIDFIELDER);
        teams.get(0).addPlayer(P97);
        Player P98 = new Player("COLOMBIA", "Wilmar", "98", PositionPlayer.MIDFIELDER);
        teams.get(1).addPlayer(P98);
        Player P99 = new Player("CHILE", "Arturo", "99", PositionPlayer.MIDFIELDER);
        teams.get(2).addPlayer(P99);
        Player P100 = new Player("PERU", "Renato", "100", PositionPlayer.MIDFIELDER);
        teams.get(3).addPlayer(P100);
        Player P101 = new Player("SENEGAL", "Cheikhou", "101", PositionPlayer.MIDFIELDER);
        teams.get(4).addPlayer(P101);
        Player P102 = new Player("ARGENTINA", "Rodrigo", "102", PositionPlayer.MIDFIELDER);
        teams.get(5).addPlayer(P102);
        Player P103 = new Player("BRASIL", "Fred", "103", PositionPlayer.MIDFIELDER);
        teams.get(6).addPlayer(P103);
        Player P104 = new Player("FRANCIA", "Paul", "104", PositionPlayer.MIDFIELDER);
        teams.get(7).addPlayer(P104);
        Player P105 = new Player("PORTUGAL", "Joao", "105", PositionPlayer.MIDFIELDER);
        teams.get(0).addPlayer(P105);
        Player P106 = new Player("INGLATERRA", "Mason", "106", PositionPlayer.MIDFIELDER);
        teams.get(1).addPlayer(P106);
        Player P107 = new Player("BELGICA", "Axel", "107", PositionPlayer.MIDFIELDER);
        teams.get(2).addPlayer(P107);
        Player P108 = new Player("CROACIA", "Mateo", "108", PositionPlayer.MIDFIELDER);
        teams.get(3).addPlayer(P108);
        Player P109 = new Player("ESPAÑA", "Rodri", "109", PositionPlayer.MIDFIELDER);
        teams.get(4).addPlayer(P109);
        Player P110 = new Player("ITALIA", "Nicolo", "110", PositionPlayer.MIDFIELDER);
        teams.get(5).addPlayer(P110);
        Player P111 = new Player("ALEMANIA", "Leon", "111", PositionPlayer.MIDFIELDER);
        teams.get(6).addPlayer(P111);
        Player P112 = new Player("URUGUAY", "Federico", "112", PositionPlayer.MIDFIELDER);
        teams.get(7).addPlayer(P112);
        Player P113 = new Player("HOLANDA", "Georginio", "113", PositionPlayer.MIDFIELDER);
        teams.get(0).addPlayer(P113);
        Player P114 = new Player("DINAMARCA", "Pierre-Emile", "114", PositionPlayer.MIDFIELDER);
        teams.get(1).addPlayer(P114);
        Player P115 = new Player("MEXICO", "Hector", "115", PositionPlayer.MIDFIELDER);
        teams.get(2).addPlayer(P115);
        Player P116 = new Player("ESTADOS UNIDOS", "Tyler", "116", PositionPlayer.MIDFIELDER);
        teams.get(3).addPlayer(P116);
        Player P117 = new Player("SUIZA", "Denis", "117", PositionPlayer.MIDFIELDER);
        teams.get(4).addPlayer(P117);
        Player P118 = new Player("COLOMBIA", "Gustavo", "118", PositionPlayer.MIDFIELDER);
        teams.get(5).addPlayer(P118);

        Player P119 = new Player("CHILE", "Charles", "119", PositionPlayer.MIDFIELDER);
        teams.get(6).addPlayer(P119);
        Player P120 = new Player("PERU", "Yoshimar", "120", PositionPlayer.MIDFIELDER);
        teams.get(7).addPlayer(P120);
        Player P121 = new Player("SENEGAL", "Bouna", "121", PositionPlayer.FORWARD);
        teams.get(0).addPlayer(P121);
        Player P122 = new Player("ARGENTINA", "Lautaro", "122", PositionPlayer.FORWARD);
        teams.get(1).addPlayer(P122);
        Player P123 = new Player("BRASIL", "Neymar", "123", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P123);
        Player P124 = new Player("FRANCIA", "Kylian", "124", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P124);
        Player P125 = new Player("PORTUGAL", "Cristiano", "125", PositionPlayer.FORWARD);
        teams.get(4).addPlayer(P125);
        Player P126 = new Player("INGLATERRA", "Harry", "126", PositionPlayer.FORWARD);
        teams.get(5).addPlayer(P126);
        Player P127 = new Player("BELGICA", "Romelu", "127", PositionPlayer.FORWARD);
        teams.get(6).addPlayer(P127);
        Player P128 = new Player("CROACIA", "Ivan", "128", PositionPlayer.FORWARD);
        teams.get(7).addPlayer(P128);
        Player P129 = new Player("ESPAÑA", "Alvaro", "129", PositionPlayer.FORWARD);
        teams.get(0).addPlayer(P129);
        Player P130 = new Player("ITALIA", "Lorenzo", "130", PositionPlayer.FORWARD);
        teams.get(1).addPlayer(P130);
        Player P131 = new Player("ALEMANIA", "Kai", "131", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P131);
        Player P132 = new Player("URUGUAY", "Luis", "132", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P132);
        Player P133 = new Player("HOLANDA", "Memphis", "133", PositionPlayer.FORWARD);
        teams.get(4).addPlayer(P133);
        Player P134 = new Player("DINAMARCA", "Kasper", "134", PositionPlayer.FORWARD);
        teams.get(5).addPlayer(P134);
        Player P135 = new Player("MEXICO", "Raul", "135", PositionPlayer.FORWARD);
        teams.get(6).addPlayer(P135);
        Player P136 = new Player("ESTADOS UNIDOS", "Christian", "136", PositionPlayer.FORWARD);
        teams.get(7).addPlayer(P136);
        Player P137 = new Player("SUIZA", "Haris", "137", PositionPlayer.FORWARD);
        teams.get(0).addPlayer(P137);
        Player P138 = new Player("COLOMBIA", "Radamel", "138", PositionPlayer.FORWARD);
        teams.get(1).addPlayer(P138);
        Player P139 = new Player("CHILE", "Alexis", "139", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P139);
        Player P140 = new Player("PERU", "Jefferson", "140", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P140);
        Player P141 = new Player("SENEGAL", "Sadio", "141", PositionPlayer.FORWARD);
        teams.get(4).addPlayer(P141);
        Player P142 = new Player("ARGENTINA", "Angel", "142", PositionPlayer.FORWARD);
        teams.get(5).addPlayer(P142);
        Player P143 = new Player("BRASIL", "Vinicius", "143", PositionPlayer.FORWARD);
        teams.get(6).addPlayer(P143);
        Player P144 = new Player("FRANCIA", "Ousmane", "144", PositionPlayer.FORWARD);
        teams.get(7).addPlayer(P144);
        Player P145 = new Player("PORTUGAL", "João", "145", PositionPlayer.FORWARD);
        teams.get(0).addPlayer(P145);
        Player P146 = new Player("INGLATERRA", "Marcus", "146", PositionPlayer.FORWARD);
        teams.get(1).addPlayer(P146);
        Player P147 = new Player("BELGICA", "Kevin", "147", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P147);
        Player P148 = new Player("CROACIA", "Luka", "148", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P148);
        Player P149 = new Player("ESPAÑA", "Sergio", "149", PositionPlayer.FORWARD);
        teams.get(4).addPlayer(P149);
        Player P150 = new Player("ITALIA", "Gianluigi", "150", PositionPlayer.FORWARD);
        teams.get(5).addPlayer(P150);
        Player P151 = new Player("ALEMANIA", "Manuel", "151", PositionPlayer.FORWARD);
        teams.get(6).addPlayer(P151);
        Player P152 = new Player("URUGUAY", "Diego", "152", PositionPlayer.FORWARD);
        teams.get(7).addPlayer(P152);
        Player P153 = new Player("HOLANDA", "Virgil", "153", PositionPlayer.FORWARD);
        teams.get(0).addPlayer(P153);
        Player P154 = new Player("DINAMARCA", "Christian", "154", PositionPlayer.FORWARD);
        teams.get(1).addPlayer(P154);
        Player P155 = new Player("MEXICO", "Hirving", "155", PositionPlayer.FORWARD);
        teams.get(2).addPlayer(P155);
        Player P156 = new Player("ESTADOS UNIDOS", "Weston", "156", PositionPlayer.FORWARD);
        teams.get(3).addPlayer(P156);
        Player P157 = new Player("SUIZA", "Granit", "157", PositionPlayer.FORWARD);
        teams.get(4).addPlayer(P157);
        Player P158 = new Player("COLOMBIA", "Juan", "158", PositionPlayer.FORWARD);
        teams.get(5).addPlayer(P158);
        Player P159 = new Player("CHILE", "Claudio", "159", PositionPlayer.FORWARD);
        teams.get(6).addPlayer(P159);
        Player P160 = new Player("PERU", "Paolo", "160", PositionPlayer.FORWARD);
        teams.get(7).addPlayer(P160);

    }

    /**
     * Descripcion : Crea y asigna equipos a los grupos A y B de forma aleatoria.
     *
     * @pre Hay 8 equipos en la lista 'teams'.
     * @post Los equipos se distribuyen aleatoriamente en los grupos A y B,
     *       con 4 equipos en cada grupo. Devuelve la lista de equipos en cada
     *       grupo.
     * @return Una cadena con los equipos de cada grupo o un mensaje de error si no
     *         hay suficientes equipos
     *         o si los grupos ya fueron generados.
     */
    public String createGroupsAB() {
        if (verifyGroup == 0) {
            StringBuilder listA = new StringBuilder("GROUP A\n");
            StringBuilder listB = new StringBuilder("GROUP B\n");

            if (teams.size() == 8) {
                boolean[] assigned = new boolean[teams.size()];
                int indexA = 0, indexB = 0;

                while (indexA < 4 || indexB < 4) {
                    int randomIndex = random.nextInt(teams.size());
                    if (!assigned[randomIndex]) {
                        if (indexA < 4) {
                            groupA.add(teams.get(randomIndex));
                            indexA++;
                        } else if (indexB < 4) {
                            groupB.add(teams.get(randomIndex));
                            indexB++;
                        }
                        assigned[randomIndex] = true;
                    }
                }

                for (Team team : groupA) {
                    listA.append(team.toString()).append("\n");
                }
                for (Team team : groupB) {
                    listB.append(team.toString()).append("\n");
                }
                verifyGroup = 1;
                return listA.toString() + "\n" + listB.toString();
            }
            return "No hay suficientes equipos para generar grupos A y B.";
        } else {
            return "Ya se han generado los grupos A y B";
        }
    }

    public boolean analizePlayer(String Dorsal, int numMatch, int team) {
        for (Match match : matches) {
            if (match.getNumMatch() == numMatch) {

                if (team == 1) {
                    for (Player player : match.getTeam1().getPlayers()) {
                        if (player.getDorsal().equals(Dorsal)) {
                            return true;
                        }
                    }
                } else {
                    for (Player player : match.getTeam2().getPlayers()) {
                        if (player.getDorsal().equals(Dorsal)) {
                            return true;
                        }
                    }
                }

            }

        }
        return false;
    }

    /**
     * Descripcion: Añade los partidos entre los equipos de los grupos A y B y
     * asigna árbitros a cada partido.
     *
     * @pre Los grupos A y B deben haberse generado y los partidos aún no deben
     *      haberse añadido.
     * @post Los partidos se crean entre todos los equipos de cada grupo, con tres
     *       árbitros
     *       asignados a cada partido. Cada partido tiene un número único.
     * @return `true` si los partidos se añadieron con éxito, `false` si los
     *         partidos ya estaban añadidos.
     */
    public boolean addMatches() {

        List<Referee> refereesAvailables = new ArrayList<>();
        List<Referee> refereesToMatch;

        if (!matches.isEmpty()) {
            return false;
        }

        for (int i = 0; i < groupA.size(); i++) {
            for (int j = i + 1; j < groupA.size(); j++) {
                refereesAvailables.clear();
                refereesToMatch = new ArrayList<>(3);

                for (Referee referee : mainReferee) {
                    if (!referee.getCountry().equals(groupA.get(i).getCountry()) &&
                            !referee.getCountry().equals(groupA.get(j).getCountry())) {
                        refereesAvailables.add(referee);
                    }
                }

                for (Referee referee : AuxReferees) {
                    if (!referee.getCountry().equals(groupA.get(i).getCountry()) &&
                            !referee.getCountry().equals(groupA.get(j).getCountry())) {
                        refereesAvailables.add(referee);
                    }
                }

                for (Referee referee : refereesAvailables) {
                    if (referee.getType().equals(TypeReferee.MAIN)) {
                        refereesToMatch.add(referee);
                        break;
                    }
                }

                for (Referee referee : refereesAvailables) {
                    if (referee.getType().equals(TypeReferee.AUXILIARY) && refereesToMatch.size() < 3) {
                        refereesToMatch.add(referee);
                    }
                }

                if (refereesToMatch.size() == 3) {
                    Match match = new Match(groupA.get(i), groupA.get(j), refereesToMatch);
                    matches.add(match);

                }
            }
        }

        for (int i = 0; i < groupB.size(); i++) {
            for (int j = i + 1; j < groupB.size(); j++) {
                refereesAvailables.clear();
                refereesToMatch = new ArrayList<>(3);

                for (Referee referee : mainReferee) {
                    if (!referee.getCountry().equals(groupB.get(i).getCountry()) &&
                            !referee.getCountry().equals(groupB.get(j).getCountry())) {
                        refereesAvailables.add(referee);
                    }
                }

                for (Referee referee : AuxReferees) {
                    if (!referee.getCountry().equals(groupB.get(i).getCountry()) &&
                            !referee.getCountry().equals(groupB.get(j).getCountry())) {
                        refereesAvailables.add(referee);
                    }
                }

                for (Referee referee : refereesAvailables) {
                    if (referee.getType().equals(TypeReferee.MAIN)) {
                        refereesToMatch.add(referee);
                        break;
                    }
                }

                for (Referee referee : refereesAvailables) {
                    if (referee.getType().equals(TypeReferee.AUXILIARY) && refereesToMatch.size() < 3) {
                        refereesToMatch.add(referee);
                    }
                }

                if (refereesToMatch.size() == 3) {
                    Match match = new Match(groupB.get(i), groupB.get(j), refereesToMatch);
                    matches.add(match);

                }
            }
        }

        for (int i = 0; i < matches.size(); i++) {

            matches.get(i).setNumMatch(i + 1);
        }

        return true;
    }

    /**
     * Descripcion: Genera las fechas para los partidos en los grupos A y B.
     *
     * @param initialDate La fecha de inicio para el primer partido.
     * @pre Los grupos A y B deben haberse generado.
     * @post Cada partido de los grupos A y B tiene una fecha asignada en intervalos
     *       de 3 días.
     * @return Una cadena que muestra cada partido con su fecha asignada o un
     *         mensaje de error
     *         si los grupos no se han generado.
     */
    public String generateMatchDates(LocalDate initialDate) {
        int auxDays = 0, auxNumMatch = 0;

        LocalDate dateAux = initialDate;
        if (verifyGroup == 0) {
            return "Primero debe generar los grupos A y B.";
        }
        int auxDate = 1;
        String list = "";

        initialDate.atTime(14, 45);

        for (int i = 0; i < groupA.size(); i++) {

            for (int j = i + 1; j < groupA.size(); j++) {
                list += "Partido: " + matches.get(auxNumMatch).getNumMatch() + " [Grupo A]"
                        + groupA.get(i).getNameTeam() + " vs "
                        + groupA.get(j).getNameTeam()
                        + " - Fecha: ["
                        + initialDate.getYear() + "-" + initialDate.getMonthValue() + "-" + initialDate.getDayOfMonth()
                        + "]\n";
                if (auxDate == 1) {
                    if (auxDays != 4) {

                        initialDate = initialDate.plusDays(3);
                        auxDays++;
                        auxDate = 0;
                    }

                }
                auxNumMatch++;
                auxDate++;
            }
        }
        auxDays = 0;
        auxDate = 1;

        list += "\n";
        for (int i = 0; i < groupB.size(); i++) {

            for (int j = i + 1; j < groupB.size(); j++) {
                list += "Partido: " + matches.get(auxNumMatch).getNumMatch() + " [Grupo B]"
                        + groupB.get(i).getNameTeam() + " vs " + groupB.get(j).getNameTeam()
                        + " - Fecha: ["
                        + dateAux.getYear() + "-" + dateAux.getMonthValue() + "-" + dateAux.getDayOfMonth() + "]\n";
                if (auxDate == 1) {
                    if (auxDays != 4) {
                        dateAux = dateAux.plusDays(3);
                        auxDays++;
                        auxDate = 0;

                    }

                }
                auxNumMatch++;
                auxDate++;
            }
        }

        return list;
    }

    /**
     * Descripcion: Imprime una lista de todos los partidos con sus árbitros
     * asignados.
     *
     * @post Genera una cadena que incluye el número de partido, los equipos, y sus
     *       árbitros asignados.
     * @return Una cadena que muestra los partidos con sus árbitros o una cadena
     *         vacía si no hay partidos.
     */
    public String printMatches() {
        String lista = "";

        for (Match match : matches) {
            if (match != null) {

                lista += "NUM <" + match.getNumMatch() + "> "
                        + match.getTeam1().getNameTeam().toUpperCase() + " vs "
                        + match.getTeam2().getNameTeam().toUpperCase() + "  arbitros" + match.refereesToString() + "\n";
            }
        }

        return lista;

    }

    public String analizeMatches(int numMatch) {
        for (Match M : matches) {

            if (M.getNumMatch() == numMatch) {
                if (M.getPlayed() == true) {
                    return "el partido ya jugó";
                }

            }

        }

        return "";
    }

    /**
     * Descripcion: Juega un partido específico, calculando los goles de cada equipo
     * en ese partido.
     *
     * @param numMatch El número del partido a jugar.
     * @pre El partido especificado debe existir en la lista de partidos.
     * @post Los goles de cada equipo se establecen en el partido especificado.
     * @return `true` si el partido se jugó con éxito.
     */
    public boolean playMatches(int numMatch) {

        for (Match M : matches) {

            if (M.getNumMatch() == numMatch) {
                if (M.getPlayed() == true) {
                    return false;

                }
            }

        }

        int goalsTeam1 = 0, goalsTeam2 = 0;

        for (Match match : matches) {
            if (match.getNumMatch() == numMatch) {

                List<Player> playersTeam1 = match.getTeam1().getPlayers();

                for (Player player : playersTeam1) {

                    goalsTeam1 += player.getGoals();

                }
            }
        }

        for (Match match : matches) {
            if (match.getNumMatch() == numMatch) {

                List<Player> playersTeam2 = match.getTeam2().getPlayers();

                for (Player player : playersTeam2) {

                    goalsTeam2 += player.getGoals();

                }
            }
        }

        for (Match match : matches) {
            if (match.getNumMatch() == numMatch) {

                match.setGoalsTeam1(goalsTeam1);
                match.setGoalsTeam2(goalsTeam2);
                match.getTeam1().setMatchPlayed(match.getTeam1().getMatchPlayed() + 1);
                match.getTeam2().setMatchPlayed(match.getTeam2().getMatchPlayed() + 1);
                match.setPlayed(true);

                for (Referee R : match.getReferees()) {

                    R.setMatchPlayed(R.getMatchPlayed() + 1);

                }

                if (goalsTeam1 > goalsTeam2) {
                    match.getTeam1().setPoints(match.getTeam1().getPoints() + 3);
                    match.getTeam1().setWins(match.getTeam1().getWins() + 1);
                    match.getTeam2().setLoses(match.getTeam2().getLoses() + 1);
                } else if (goalsTeam1 < goalsTeam2) {
                    match.getTeam2().setPoints(match.getTeam2().getPoints() + 3);
                    match.getTeam2().setWins(match.getTeam2().getWins() + 1);
                    match.getTeam1().setLoses(match.getTeam1().getLoses() + 1);

                } else {
                    match.getTeam1().setPoints(match.getTeam1().getPoints() + 1);
                    match.getTeam2().setPoints(match.getTeam2().getPoints() + 1);
                    match.getTeam1().setDraws(match.getTeam1().getDraws() + 1);
                    match.getTeam2().setDraws(match.getTeam2().getDraws() + 1);

                }

            }
        }
        return true;
    }

    /**
     * Descripcion: Imprime la lista de jugadores de un equipo específico.
     *
     * @param nameTeam El nombre del equipo del que se desean listar los jugadores.
     * @return Una cadena con los nombres y dorsales de los jugadores del equipo o
     *         un mensaje de error si no existe el equipo.
     */
    public String printPlayerTeam(String nameTeam) {
        List<Player> players;
        String listPlayers = "";
        for (Team team : teams) {

            if (team.getNameTeam().equals(nameTeam)) {
                players = team.getPlayers();

                for (Player P : players) {
                    listPlayers += P.getName() + "D: [" + P.getDorsal() + "]\t |G: " + P.getGoals() + "\t| A: "
                            + P.getAssists() + "\t| YC: " + P.getYellowCards() + "\t| RC: " + P.getRedCards() + "| \n";

                }

                return listPlayers;

            }
        }
        return " error";
    }

    /**
     * Descripcion: Imprime la lista de jugadores de un equipo en un partido
     * específico.
     *
     * @param numMatch El número del partido.
     * @param T1orT2   1 para el equipo 1 del partido, 2 para el equipo 2.
     * @return Una cadena con los nombres y dorsales de los jugadores del equipo en
     *         el partido o un mensaje de error si el partido no existe.
     */
    public String printPlayerTeam(int numMatch, int T1orT2) {
        List<Player> players;
        String listPlayers = "";

        switch (T1orT2) {
            case 1 -> {
                for (Match match : matches) {

                    if (match.getNumMatch() == numMatch) {
                        players = match.getTeam1().getPlayers();

                        for (Player P : players) {
                            listPlayers += P.getName() + "--[" + P.getDorsal() + "] \n";

                        }

                        return listPlayers;

                    }
                }
            }

            case 2 -> {
                for (Match match : matches) {

                    if (match.getNumMatch() == numMatch) {
                        players = match.getTeam2().getPlayers();

                        for (Player P : players) {
                            listPlayers += P.getName() + "--[" + P.getDorsal() + "] \n";

                        }

                        return listPlayers;

                    }
                }

                return listPlayers;

            }
        }
        return " error";
    }

    /**
     * Descripcion: Imprime las posiciones de los equipos con el marcador de cada
     * partido.
     *
     * @return Una cadena con el número del partido y los goles de cada equipo.
     */
    public String listPositions() {
        String lista = "";
        for (Match matchList : matches) {

            lista += "NUM <" + matchList.getNumMatch() + "> [" + matchList.getGoalsTeam1() + "]" +
                    matchList.getTeam1().getNameTeam().toUpperCase() + "--"
                    + matchList.getTeam2().getNameTeam().toUpperCase() + "[" + matchList.getGoalsTeam2() + "]" + "\n";

        }

        return lista;
    }

    /**
     * Descripcion: Asigna una cantidad de goles a un jugador según su dorsal.
     *
     * @param dorsal El dorsal del jugador.
     * @param goals  La cantidad de goles a añadir.
     * @return `true` si los goles fueron asignados con éxito.
     */
    public boolean setGoalToPlayer(String dorsal, int goals) {

        for (Team team : teams) {
            for (Player player : team.getPlayers()) {
                if (player.getDorsal().equals(dorsal)) {
                    player.setGoals(player.getGoals() + goals);
                }
            }
        }

        return true;

    }

    /**
     * Descripcion: Asigna una asistencia a un jugador según su dorsal.
     *
     * @param dorsal El dorsal del jugador.
     * @return `true` si los goles fueron asignados con éxito.
     */
    public boolean setAssistToPlayer(String dorsal) {

        for (Team team : teams) {
            for (Player player : team.getPlayers()) {
                if (player.getDorsal().equals(dorsal)) {
                    player.setAssists(player.getAssists() + 1);
                }
            }
        }

        return true;

    }

    /**
     * Descripcion: Imprime la lista de todos los equipos registrados.
     *
     * @return Una cadena con los nombres de todos los equipos.
     */
    public String printTeams() {

        String listTeams = "";
        for (Team team : teams) {
            listTeams += team.getNameTeam() + "\n";
        }
        return listTeams;
    }

    public boolean setYellowCardToPlayer(String dorsal, int yellowCards) {

        for (Team team : teams) {
            for (Player player : team.getPlayers()) {
                if (player.getDorsal().equals(dorsal)) {
                    player.setYellowCards(player.getYellowCards() + yellowCards);
                }
            }
        }

        return true;
    }

    public boolean setRedCardToPlayer(String dorsal, int redCards) {

        for (Team team : teams) {
            for (Player player : team.getPlayers()) {
                if (player.getDorsal().equals(dorsal)) {
                    player.setRedCards(player.getRedCards() + redCards);
                }
            }
        }

        return true;
    }

}
