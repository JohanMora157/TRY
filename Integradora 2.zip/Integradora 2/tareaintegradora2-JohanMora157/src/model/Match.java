package model;

import java.util.List;

public class Match {

    private int numMatch;
    private Team team1;
    private Team team2;
    private int goalsTeam1;
    private int goalsTeam2;
    private List<Referee> referees;
    private boolean played;

    public Match(Team team1, Team team2, List<Referee> referees) {
        this.team1 = team1;
        this.team2 = team2;
        this.referees = referees;
        this.played = false;
    }

    public boolean getPlayed() {
        return played;
    }

    public void setPlayed(boolean played) {
        this.played = played;
    }

    public Team getTeam1() {
        return team1;
    }

    public void setTeam1(Team team1) {
        this.team1 = team1;
    }

    public Team getTeam2() {
        return team2;
    }

    public void setTeam2(Team team2) {
        this.team2 = team2;
    }

    public int getGoalsTeam1() {
        return goalsTeam1;
    }

    public void setGoalsTeam1(int goalsTeam1) {
        this.goalsTeam1 = goalsTeam1;
    }

    public int getGoalsTeam2() {
        return goalsTeam2;
    }

    public void setGoalsTeam2(int goalsTeam2) {
        this.goalsTeam2 = goalsTeam2;
    }

    public List<Referee> getReferees() {
        return referees;
    }

    public void setReferees(List<Referee> referees) {
        this.referees = referees;
    }

    public void addReferee(Referee referee) {
        this.referees.add(referee);
    }

    public int getNumMatch() {
        return numMatch;
    }

    public void setNumMatch(int numMatch) {
        this.numMatch = numMatch;
    }

    /**
     * Obtiene el resultado del partido en formato de cadena.
     *
     * @return Cadena con el resultado del partido en formato "Resultado del
     *         partido: EQUIPO1 golesTeam1 - golesTeam2 EQUIPO2".
     */
    public String getMatchResult() {
        return "Resultado del partido: " + team1.getNameTeam().toUpperCase() + " " + goalsTeam1 + " - " + goalsTeam2
                + " "
                + team2.getNameTeam().toUpperCase();
    }

    /**
     * Muestra la información de los árbitros en formato de cadena.
     *
     * @return Cadena con la lista de árbitros y sus detalles en el formato "Arbitro
     *         tipo: TIPO = Nombre - Pais: PAIS".
     */
    public String refereesToString() {
        String result = "";
        for (Referee referee : referees) {
            result += " Arbitro tipo : " + referee.getType() + "=" + referee.getName() + "-" + "Pais: "
                    + referee.getCountry();
        }
        return result;
    }

}
