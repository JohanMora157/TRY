package model;

import java.util.ArrayList;
import java.util.List;

public class Team {
    private String nameTeam;
    private String country;
    private String nameCoach;
    private List<Player> players;
    private int matchPlayed;
    private int wins;
    private int loses;
    private int draws;
    private int points;
    private int goalsAgainst;

    public Team(String nameTeam, String country, String nameCoach) {
        this.nameTeam = nameTeam;
        this.country = country;
        this.nameCoach = nameCoach;
        this.players = new ArrayList<>();
        this.matchPlayed = 0;
        this.wins = 0;
        this.loses = 0;
        this.draws = 0;
        this.points = 0;
        this.goalsAgainst = 0;
    }

    public String getNameTeam() {
        return nameTeam;
    }

    public void setNameTeam(String nameTeam) {
        this.nameTeam = nameTeam;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getNameCoach() {
        return nameCoach;
    }

    public void setNameCoach(String nameCoach) {
        this.nameCoach = nameCoach;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public void setPlayers(List<Player> players) {
        this.players = players;
    }

    /**
     * Agrega un nuevo jugador al equipo si no se ha alcanzado el límite de 20
     * jugadores.
     *
     * @param newPlayer El jugador a agregar al equipo.
     * @return true si el jugador se agregó exitosamente, false si el equipo ya
     *         tiene 20 jugadores.
     */
    public boolean addPlayer(Player newPlayer) {
        if (players.size() < 20) { // Máximo 20 jugadores
            players.add(newPlayer);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "[Team= " + nameTeam + ", Pais= " + country + ", Coach= " + nameCoach + "]";
    }

    public int getMatchPlayed() {
        return matchPlayed;
    }

    public void setMatchPlayed(int matchPlayed) {

        this.matchPlayed = matchPlayed;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public int getLoses() {
        return loses;
    }

    public void setLoses(int loses) {
        this.loses = loses;
    }

    public int getDraws() {
        return draws;
    }

    public void setDraws(int draws) {
        this.draws = draws;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getGoalsAgainst() {
        return goalsAgainst;
    }

    public void setGoalsAgainst(int goalsAgainst) {
        this.goalsAgainst = goalsAgainst;
    }
}
