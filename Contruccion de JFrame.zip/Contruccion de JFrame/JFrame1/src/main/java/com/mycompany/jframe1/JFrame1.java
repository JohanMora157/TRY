/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jframe1;

/**
 *
 * @author ASUS
 */
public class JFrame1 {

    public static void main(String[] args) {
       
   
        duro panela = new duro();
        panela.setVisible(true);
        
                }     
}
