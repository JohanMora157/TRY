/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jframe2;

/**
 *
 * @author ASUS
 */
public class JFrame2 {

    public static void main(String[] args) {
        JFrameManejadores manejador = new JFrameManejadores();
        manejador.setVisible(true);
    }
}
