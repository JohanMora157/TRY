/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jframe3;

/**
 *
 * @author ASUS
 */
public class JFrame3 {

    public static void main(String[] args) {
        JFrameCalculadora calcu = new JFrameCalculadora();
        calcu.setVisible(true);
    }
}
