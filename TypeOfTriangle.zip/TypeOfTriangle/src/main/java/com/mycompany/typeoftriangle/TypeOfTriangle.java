/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.typeoftriangle;
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class TypeOfTriangle {

    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);
    
   System.out.println("---IDENTIFICADOR DE TIPO DE TRIANGULO---");
   System.out.println("Digite la medida de la base de el triangulo:");
   double baseT = scanner.nextDouble();
   System.out.println("Digite la medida de un lado:");
   double lado1 = scanner.nextDouble();
   System.out.println("Digite la medida de el otro lado:");
   double lado2 = scanner.nextDouble();
   System.out.println("Digite la altura del triangulo:");
   double altura = scanner.nextDouble();

String Triangulo;
   if( baseT == lado1 && lado1 == lado2){
System.out.println("Las medidas de sus lados son iguales, es un triangulo [equilátero]");
Triangulo="equilatero";
   }else if(baseT == lado1 || baseT == lado2 || lado1 == lado2){
System.out.println("las medidas de dos de sus lados son inguales, es un triangulo [isósceles]");
Triangulo="isosceles";
   }else{
System.out.println("Ninguno de sus lados son iguales, es un triangulo [Escaleno]");
Triangulo="escaleno";
   }
double anguloA=0,anguloB=0,anguloC=0;

switch (Triangulo) {
    case "equilatero":

    anguloA=60.0;
    anguloB=60.0;
    anguloC=60.0;
        
        break;

    case "isosceles":
    if (baseT == lado1) {
        anguloC = Math.toDegrees(Math.acos((baseT*baseT  + lado1*lado1 - lado2*lado2) / (2 * baseT * lado1)));
        anguloA = anguloB = (180 - anguloC) / 2;
    } else if (baseT == lado2) {
        anguloB = Math.toDegrees(Math.acos((baseT*baseT  + lado2*lado2 - lado1*lado1) / (2 * baseT * lado2)));
        anguloA = anguloC = (180 - anguloB) / 2;
    } else {
        anguloA = Math.toDegrees(Math.acos((lado1*lado1 + lado2*lado2 - baseT*baseT) / (2 * lado1 * lado2)));
        anguloB = anguloC = (180 - anguloA) / 2;
    }
        break;

    case"escaleno":
    
    anguloA = Math.toDegrees(Math.cos((lado1*lado1 + lado2*lado2 - baseT*baseT) / (2 * lado1 * lado2)));
    anguloB = Math.toDegrees(Math.cos((baseT*baseT + lado2*lado2 - lado1*lado1) / (2 * baseT * lado2)));
    anguloC = 180 - anguloA - anguloB;
        break;
    
}

double anguloA3decimales = Math.round(anguloA * 1000.0) / 1000.0; 
double anguloB3decimales = Math.round(anguloB * 1000.0) / 1000.0;
double anguloC3decimales = Math.round(anguloC * 1000.0) / 1000.0;

System.out.println("Ángulo A: " + anguloA3decimales + "° grados");
System.out.println("Ángulo B: " + anguloB3decimales + "° grados");
System.out.println("Ángulo C: " + anguloC3decimales + "° grados");

double areaTriangulo = ((baseT*altura)/2);
System.out.println("El area del triangilo "+Triangulo+" calculado es :"+areaTriangulo);
       
    
    }
}
